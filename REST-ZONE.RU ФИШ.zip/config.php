<?php
$token = '5306658145:AAEQt2KO9rtA6kOE9bNTgTrgn2kUxaVNqoE';
$chat_id = '-630126271';